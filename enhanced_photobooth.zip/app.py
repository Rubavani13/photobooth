from flask import Flask, render_template, request, send_from_directory
import os, base64, cv2
import numpy as np
from datetime import datetime

app = Flask(__name__)
PHOTO_DIR = os.path.join('static', 'photos')
FRAME_DIR = os.path.join('static', 'frames')

os.makedirs(PHOTO_DIR, exist_ok=True)

def cartoonize_image(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.medianBlur(gray, 7)
    edges = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                  cv2.THRESH_BINARY, 9, 9)
    color = cv2.bilateralFilter(img, 9, 300, 300)
    return cv2.bitwise_and(color, color, mask=edges)

@app.route("/")
def index():
    photos = sorted(os.listdir(PHOTO_DIR), reverse=True)
    frames = sorted(os.listdir(FRAME_DIR))
    return render_template("index.html", photos=photos, frames=frames)

@app.route("/capture", methods=["POST"])
def capture():
    image_data = request.form["image"]
    filter_type = request.form["filter"]
    frame = request.form["frame"]

    image_data = image_data.split(",")[1]
    img_array = np.frombuffer(base64.b64decode(image_data), np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)

    # Apply filter
    if filter_type == "grayscale":
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    elif filter_type == "cartoon":
        img = cartoonize_image(img)

    # Overlay frame
    if frame:
        frame_path = os.path.join(FRAME_DIR, frame)
        if os.path.exists(frame_path):
            overlay = cv2.imread(frame_path, cv2.IMREAD_UNCHANGED)
            overlay = cv2.resize(overlay, (img.shape[1], img.shape[0]))
            if overlay.shape[2] == 4:
                alpha = overlay[:, :, 3] / 255.0
                for c in range(3):
                    img[:, :, c] = (1 - alpha) * img[:, :, c] + alpha * overlay[:, :, c]

    filename = datetime.now().strftime("%Y%m%d%H%M%S") + ".jpg"
    filepath = os.path.join(PHOTO_DIR, filename)
    cv2.imwrite(filepath, img)
    return "Saved"

@app.route("/download/<filename>")
def download(filename):
    return send_from_directory(PHOTO_DIR, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)
