from flask import Flask, render_template, request
import os
import base64
from datetime import datetime

app = Flask(__name__)
PHOTO_DIR = os.path.join('static', 'photos')
os.makedirs(PHOTO_DIR, exist_ok=True)

@app.route('/')
def index():
    photos = os.listdir(PHOTO_DIR)
    photos.sort(reverse=True)
    return render_template('index.html', photos=photos)

@app.route('/capture', methods=['POST'])
def capture():
    image_data = request.form['image']
    image_data = image_data.split(',')[1]  # Remove header
    image_bytes = base64.b64decode(image_data)

    filename = datetime.now().strftime('%Y%m%d%H%M%S') + '.png'
    filepath = os.path.join(PHOTO_DIR, filename)

    with open(filepath, 'wb') as f:
        f.write(image_bytes)

    return 'Saved'

if __name__ == '__main__':
    app.run(debug=True)
